<?php

namespace App\Http\Controllers\Accountant;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\StudentFee;

class DashboardController extends Controller
{
    public function index()
    {
        $allFees = StudentFee::all();
        $totalExpected = $allFees->sum('total_amount');
        $totalCollected = $allFees->sum('paid_amount');
        $totalPending = $allFees->where('status', '!=', 'paid')->sum('pending_amount');

        return view('accountant.dashboard', compact('totalExpected', 'totalCollected', 'totalPending'));
    }
}
