@extends('layouts.app')

@section('header_title', 'Financial Command Center')

@section('content')
    <!-- Welcome Banner -->
    <div class="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 rounded-2xl p-8 mb-8 relative overflow-hidden shadow-2xl shadow-emerald-900/20">
        <div class="relative z-10">
            <h2 class="text-2xl font-black text-white mb-1 tracking-tight">Financial Command Center</h2>
            <p class="text-emerald-100 text-sm font-bold uppercase tracking-widest">Active Revenue & Collections</p>
        </div>
        <div class="absolute -right-10 -top-10 w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>
        <div class="absolute right-20 -bottom-10 w-32 h-32 bg-cyan-400/20 rounded-full blur-3xl"></div>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        @foreach([
            ['Expected Revenue', '₹' . number_format($totalExpected), 'bi-wallet2', 'violet'],
            ['Total Collected', '₹' . number_format($totalCollected), 'bi-safe-fill', 'emerald'],
            ['Outstanding Dues', '₹' . number_format($totalPending), 'bi-exclamation-octagon-fill', 'rose'],
        ] as $stat)
        <div class="p-6 bg-white rounded-3xl border border-slate-100 shadow-xl shadow-slate-200/50 group hover:-translate-y-1 transition-transform duration-300">
            <div class="flex items-center justify-between mb-4">
                <div class="h-12 w-12 rounded-2xl bg-{{ $stat[3] }}-50 text-{{ $stat[3] }}-600 flex items-center justify-center text-xl shadow-inner group-hover:bg-{{ $stat[3] }}-100 transition-colors">
                    <i class="bi {{ $stat[2] }}"></i>
                </div>
            </div>
            <p class="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">{{ $stat[0] }}</p>
            <h3 class="text-3xl font-black text-slate-800 tracking-tight">{{ $stat[1] }}</h3>
        </div>
        @endforeach
    </div>

    <!-- Quick Actions -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="p-8 bg-slate-900 rounded-3xl relative overflow-hidden group hover:shadow-2xl hover:shadow-emerald-500/20 transition-all">
            <div class="relative z-10">
                <div class="h-12 w-12 rounded-2xl bg-white/10 text-emerald-400 flex items-center justify-center text-xl mb-6 backdrop-blur-md">
                    <i class="bi bi-cash-coin"></i>
                </div>
                <h3 class="text-xl font-black text-white mb-2">Process Payments</h3>
                <p class="text-sm border-l-2 border-emerald-500 pl-3 text-slate-400 font-medium mb-6">Access the active fee roster to log incoming transactions and authorize student payments instantly.</p>
                <x-button variant="primary" href="{{ route('accountant.fees.index') }}" class="!bg-emerald-500 hover:!bg-emerald-400 !text-slate-900 border-none w-full sm:w-auto shadow-lg shadow-emerald-500/30">
                    Open Fee Gateway &rarr;
                </x-button>
            </div>
            <div class="absolute -right-8 -bottom-8 opacity-5 group-hover:scale-110 transition-transform duration-700">
                <i class="bi bi-safe text-9xl text-white"></i>
            </div>
        </div>
    </div>
@endsection
